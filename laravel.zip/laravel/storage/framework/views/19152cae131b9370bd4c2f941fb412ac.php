<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Our Products</h1>
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(asset('images/placeholder.jpg')); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                    <div class="card-body">
    <h5 class="card-title"><?php echo e($product->name); ?></h5>
    <p class="card-text"><?php echo e(Str::limit($product->description, 100)); ?></p>
    <p class="card-text"><strong>Price: $<?php echo e(number_format($product->price, 2)); ?></strong></p>
    <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-primary">View Details</a>
    
    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-success">Add to Cart</button>
    </form>
</div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ihsangokalp/Documents/Computer Science/project folder/ecommerce-site/laravel/resources/views/products/index.blade.php ENDPATH**/ ?>