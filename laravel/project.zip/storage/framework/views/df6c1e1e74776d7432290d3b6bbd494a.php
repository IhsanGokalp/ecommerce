<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Shopping Cart</h2>

    <?php if($cartItems->count() > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $total = 0; ?>
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $subtotal = $item->quantity * $item->product->price;
                            $total += $subtotal;
                        ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td>$<?php echo e(number_format($item->product->price, 2)); ?></td>
                            <td>
                                <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="d-flex align-items-center">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($item->product_id); ?>">
                                    <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" 
                                           min="1" max="<?php echo e($item->product->stock); ?>" 
                                           class="form-control form-control-sm" style="width: 70px">
                                    <button type="submit" class="btn btn-sm btn-secondary ms-2">Update</button>
                                </form>
                            </td>
                            <td>$<?php echo e(number_format($subtotal, 2)); ?></td>
                            <td>
                                <form action="<?php echo e(route('cart.remove', $item->product_id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                        <td><strong>$<?php echo e(number_format($total, 2)); ?></strong></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-warning">Clear Cart</button>
            </form>

            <div>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Continue Shopping</a>
                <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary">Proceed to Checkout</a>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            Your cart is empty! <a href="<?php echo e(route('products.index')); ?>">Continue shopping</a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ihsangokalp/Documents/Computer Science/project folder/ecommerce-site/laravel/resources/views/cart/index.blade.php ENDPATH**/ ?>